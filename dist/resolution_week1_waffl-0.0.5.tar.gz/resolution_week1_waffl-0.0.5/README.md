# Simple lil todo list

lets you keep track of tasks to do and keep track of previously completed tasks

